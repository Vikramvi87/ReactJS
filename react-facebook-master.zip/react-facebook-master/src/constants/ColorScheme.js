// @flow
export default {
  LIGHT: 'light',
  DARK: 'dark',
};
