// @flow
export default {
  SMALL: 'small',
  LARGE: 'large',
};
