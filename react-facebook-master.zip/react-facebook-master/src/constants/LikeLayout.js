// @flow
export default {
  STANDARD: 'standard',
  BUTTON_COUNT: 'button_count',
  BUTTON: 'button',
  BOX_COUNT: 'box_count',
};
