// @flow
export default {
  LIKE: 'like',
  RECOMMEND: 'recommend',
};
