// @flow
export default {
  SMALL: 'small',
  MEDIUM: 'medium',
  STANDARD: 'standard',
  LARGE: 'large',
  XLARGE: 'xlarge',
};
