// @flow
export default {
  BLUE: 'blue',
  WHITE: 'white',
};
