// @flow
export default {
  SOCIAL: 'social',
  REVERSE_TIME: 'reverse_time',
  TIME: 'time',
};
