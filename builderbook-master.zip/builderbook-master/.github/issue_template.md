<!-- Before creating your issue, please read the following:

(1) To report a bug in the code, please proceed with creating an issue.

(2) To ask a general question or share a suggestion about the code or our books, please create a new discussion: https://github.com/builderbook/builderbook/discussions 

-->
